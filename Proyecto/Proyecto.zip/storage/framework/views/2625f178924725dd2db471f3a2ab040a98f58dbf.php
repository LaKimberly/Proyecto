<div class="sidebar" data-color="orange" data-background-color="white"
    data-image="<?php echo e(asset('material')); ?>/img/sidebar-1.jpg">
    <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="<?php echo e(route('home')); ?>" class="simple-text logo-normal">
      <?php echo e(__('Apetitos')); ?>

    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item<?php echo e($activePage == 'menu' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('product.menu')); ?>">
          <i class="material-icons">restaurant_menu</i>
            <p><?php echo e(__('Menu')); ?></p>
        </a>
      </li>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_index')): ?>
      <li class="nav-item <?php echo e(($activePage == 'permissions' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" data-toggle="collapse" href="#credenciales" aria-expanded="true">
          <i class="material-icons">fingerprint</i>
          <p><?php echo e(__('Credenciales')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse show" id="credenciales">
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'permissions' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('permissions.index')); ?>">
              <i class="material-icons">engineering</i>
                <span class="sidebar-normal">Permisos</span>
              </a>
            </li>
          </ul>
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'roles' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('roles.index')); ?>">
              <i class="material-icons">manage_accounts</i>
                <span class="sidebar-normal">Roles</span>
              </a>
            </li>
          </ul>
        </div>
      </li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_index')): ?>
      <li class="nav-item<?php echo e($activePage == 'users' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
          <i class="material-icons">content_paste</i>
            <p>Usuarios</p>
        </a>
      </li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_index')): ?>
      <li class="nav-item<?php echo e($activePage == 'Productos' ? ' active' : ''); ?>">
        <a class="nav-link" href="/product/index">
          <i class="material-icons">inventory</i>
            <p><?php echo e(__('Productos')); ?></p>
        </a>
      </li>
      <?php endif; ?>
      <li class="nav-item<?php echo e($activePage == 'icons' ? ' active' : ''); ?>">
        <a class="nav-link" href="#">
          <i class="material-icons">bubble_chart</i>
          <p><?php echo e(__('Icons')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'map' ? ' active' : ''); ?>">
        <a class="nav-link" href="#">
          <i class="material-icons">location_ons</i>
            <p><?php echo e(__('Maps')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'notifications' ? ' active' : ''); ?>">
        <a class="nav-link" href="#">
          <i class="material-icons">notifications</i>
          <p><?php echo e(__('Notifications')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'language' ? ' active' : ''); ?>">
        <a class="nav-link" href="#">
          <i class="material-icons">language</i>
          <p><?php echo e(__('RTL Support')); ?></p>
        </a>
      </li>
      <li class="nav-item active-pro<?php echo e($activePage == 'upgrade' ? ' active' : ''); ?>">
        <a class="nav-link text-white bg-danger" href="#">
          <i class="material-icons text-white">unarchive</i>
          <p><?php echo e(__('Upgrade to PRO')); ?></p>
        </a>
      </li>
        </ul>
    </div>
</div>
<?php /**PATH C:\Users\Andres Escobar\Desktop\Proyecto sourcetree\Proyecto\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>