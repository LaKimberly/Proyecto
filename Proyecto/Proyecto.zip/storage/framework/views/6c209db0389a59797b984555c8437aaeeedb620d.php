

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['activePage' => 'dashboard', 'titlePage' => __('Dashboard')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Andres Escobar\Desktop\Proyecto sourcetree\Proyecto\resources\views/home.blade.php ENDPATH**/ ?>