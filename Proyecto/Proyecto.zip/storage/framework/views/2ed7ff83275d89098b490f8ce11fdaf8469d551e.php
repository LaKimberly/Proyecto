
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title">Vista detallada del Producto <?php echo e($product->productName); ?> </h4>
                            <p class="card-category"></p>
                        </div>
                        <div class="card-body">
                            <?php if(session('success')): ?>
                                <div class="alert alert-success" role="success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>
                            <div class="row">
                                
                                    <div class="item col-xs-6 col-lg-6">
                                    <div class="card card-user">
                                        <div class="card-body">
                                            <p class="card-text">
                                            <div class="auto">
                                                <img src="/storage/<?php echo e($product->img); ?>" alt="image"
                                                        class="avatar" width="200">
                                                <a href="#" class="d-flex">
                                                    <h5 class="title mx-5"> <?php echo e($product->productName); ?> </h5>
                                                </a>
                                                <p class="description">
                                                    Precio: $ <?php echo e($product->productPrice); ?><br>
                                                    Descripcion: <?php echo e($product->ProductDescription); ?><br>
                                                    Calificacion: <?php echo e($product->productQualication); ?><br>
                                                </p>
                                            </div>
                                            </p>
                                        </div>
                                        <div class="card-footer">
                                            <div class="button-containe">
                                                <a href="<?php echo e(route('product.index', $product->id)); ?>"
                                                    class="btn btn-sm btn-success mr-3"> Volver </a>
                                                <a href="<?php echo e(route('product.edit', $product->id)); ?>"
                                                    class="btn-sm btn-primary mr-3 "> Editar </a>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['activePage' => 'Productos', 'titlePage' => __('Detalles del Producto')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Andres Escobar\Desktop\Proyecto sourcetree\Proyecto\resources\views/Productviews/show.blade.php ENDPATH**/ ?>