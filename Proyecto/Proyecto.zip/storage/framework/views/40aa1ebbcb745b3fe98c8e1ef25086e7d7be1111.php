
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-primary">
                        <div class="card-title">Usuarios</div>
                        <p class="card-category">Vista detallada del usuario <?php echo e($user->username); ?></p>
                    </div>
                    <!--body-->
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="card card-user">
                                        <div class="card-body">
                                        <p class="card-text">
                                            <div class="author">
                                                <a href="#" class="d-flex">
                                                    <img src="<?php echo e(asset('/img/avatar.png')); ?>" alt="image" class="avatar">
                                                    <h5 class="title mx-3"><?php echo e($user->username); ?></h5>
                                                </a>
                                                <p class="description">
                                                     <?php echo e($user->address); ?> <br>
                                                     <?php echo e($user->phonenumber); ?> <br>
                                                     <?php echo e($user->email); ?> <br>
                                                        <?php $__empty_1 = true; $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <span class="badge badge-info"><?php echo e($role->name); ?></span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <span class="badge badge-danger">No roles</span>
                                                        <?php endif; ?>
                                                     <br>
                                                     Creado: <?php echo e($user->created_at); ?> <br>
                                                     Actualizado: <?php echo e($user->updated_at); ?> <br>
                                                </p>                                                
                                            </div>
                                        </p>
                                    </div>
                                    <div class="card-footer">
                                        <div class="button-container">
                                            <a href="<?php echo e(route('user.index')); ?>" class="btn btn-sm btn-success mr-3">Volver</a>
                                            <a href="<?php echo e(route('user.edit', $user->id)); ?>" class="btn btn-sm btn-primary mr-3">Editar</a>                                       </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div><!--end card body-->
                    </div> 
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['activePage' => 'users', 'titlePage' => 'Detalles del usuario'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Andres Escobar\Desktop\Proyecto sourcetree\Proyecto\resources\views/users/show.blade.php ENDPATH**/ ?>