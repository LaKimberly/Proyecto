
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="panel-body">
                            <div class="row">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item col-xs-4 col-lg-4 ">
                                    <div class="card" style="width: 15rem;">
                                        <img class="card-img-top" src="/storage/<?php echo e($product->img); ?>" alt="Card image cap" class="avatar" width="500" height="200">
                                        <div class="card-body">
                                            <p class="card-text">
                                                Precio: $ <?php echo e($product->productPrice); ?><br>
                                                Calificacion: <?php echo e($product->productQualication); ?>

                                            </p>
                                        </div>
                                        <div class="item col-xs-4">
                                            
                                            <a href="#" class="btn btn-warning"> <i class="material-icons">remove</i>
                                                <a href="#" class="btn btn-warning"> <i class="material-icons">shopping_cart</i>
                                                    <a href="#" class="btn btn-warning"> <i class="material-icons">add</i></a>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer mr-auto">
                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', [ 'activePage' => 'menu', 'titlePage' => __('Productos')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Andres Escobar\Desktop\Proyecto sourcetree\Proyecto\resources\views/Productviews/menu.blade.php ENDPATH**/ ?>