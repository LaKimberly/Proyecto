
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Productos Registrados</h4>
                        <p class="card-category"></p>
                    </div>
                    <div class="card-body">
                        <?php if(session('success')): ?>
                        <div class="alert alert-success" role="success">
                            <?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?>
                        <div class="table-responsive">
                        <div class="row">
                            <div class="col-12 text-right ">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_create')): ?>
                                <a href="<?php echo e(route('product.create')); ?>" class="btn btn-facebook">Añadir Producto</a>
                                <?php endif; ?>
                            </div>
                        </div>
                            <table class="table">
                                <thead class="text-primary">
                                    <th>ID</th>
                                    <th>NOMBRE</th>
                                    <th>PRECIO</th>
                                    <th class="text-rigth">ACCIONES</th>
                                </thead>
                                <tbody>
                                   <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($product-> id); ?></td>
                                        <td><?php echo e($product-> productName); ?></td>
                                        <td><?php echo e($product-> productPrice); ?></td>
                                        <td class="td-actions text-centered">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_show')): ?>
                                               <a href="<?php echo e(route('product.show', $product->id)); ?>" class="btn btn-info"> <i class="material-icons">person</i> </a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_edit')): ?>
                                               <a href="<?php echo e(route('product.edit', $product->id)); ?>" class="btn btn-warning"> <i class="material-icons">edit</i> </a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_destroy')): ?>
                                            <form action="<?php echo e(route('product.delete', $product->id)); ?>" method="POST" style="display: inline-block;" onsubmit="return confirm('Esta seguro que desea Eliminar este producto')">
                                                 <?php echo csrf_field(); ?>
                                                  <?php echo method_field('DELETE'); ?>
                                                <button class=" btn btn-danger" type="submit" rel="tooltip">
                                                 <i class="material-icons">close</i>
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>

                        </div>

                    </div>

                    <div class="card-footer mr-auto">
                        <?php echo e($products->links()); ?>



                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', [ 'activePage' => 'Productos', 'titlePage' => __('Productos')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Andres Escobar\Desktop\Proyecto sourcetree\Proyecto\resources\views/Productviews/index.blade.php ENDPATH**/ ?>